a =1
b = input("hahaha")
if a == b[0]:
    print("Yes")
else:
    print("why")