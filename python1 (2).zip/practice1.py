myList = [10,20,30]

if 10 in myList:
    print("True")
else:
    print("False")

if 40 not in myList:
    print("T")
else:
    print("F")