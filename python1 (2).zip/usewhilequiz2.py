#quiz 2
count=3
row =5
value = 5
while count>0:
     value=5
     while value>0:
          row=5
          while row>0:
               print("*",end='')
               row -=1
          print()
          value -= 1
     print()
     count -=1