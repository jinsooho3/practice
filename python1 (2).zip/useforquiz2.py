#quiz 2

line=5 #몇줄짜리 사각형
a=3       #반복횟수
for count in range(a):  #반복횟수만큼 반복
     for value in range(line):     
          for j in range(line):
               print("*"," ",end='')
          print()
     print()