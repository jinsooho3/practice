import random

onelist=[]
for a in range(30):
    onelist.append(random.randint(1,50))

for cd in range(len(onelist)):
    chgnum=0
    for de in range(cd+1, len(onelist)):
        if onelist[cd] > onelist[de]:
            chgnum = onelist[cd]
            onelist[cd]=onelist[de]
            onelist[de]=chgnum
print(onelist)