#quiz 1
num =5 # int(input("양의 정수 입력 : "))
value=1

while value <= num:
     i = 1
     while i <= value:
          print(i," ", end='')
          i +=1
     value +=1
     print()