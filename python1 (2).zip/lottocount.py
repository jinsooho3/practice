import random
count=0
lot_grade = 0
alist=[]
for count in range(6):
    a = random.randint(1,45)
#중복번호가 나올경우 다시 난수 입력받기
    while a in alist:
        a = random.randint(1,45)
#리스트에 난수 넣기
    alist.append(a)

while lot_grade <4:
    lot_grade=0
    play_list =[]
    while len(play_list)<6:
        randnum= random.randint(1,45)
        while randnum in play_list:
            randnum = random.randint(1,45)
        play_list.append(randnum)

    for a in play_list:
        if a in alist:
            lot_grade += 1
    count+=1
alist.sort()
play_list.sort()
print(alist)
print(play_list)
print(count)