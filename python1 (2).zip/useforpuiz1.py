#quiz 1
line = int(input("양의 정수 입력 : "))
for value in range(line):
     for j in range(value+1):
          print(j+1," ", end='')
     print()
