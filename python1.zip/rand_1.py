'''
import random
for random_num in random.sample(range(1, 46),6):
        print(random_num,"",end='')
'''
import random

for count in range(6):
    