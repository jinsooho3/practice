import random

print("===================")
print("1.자동")
print("2.수동")
print("3.프로그램종료")
print("===================")
select_num = int(input("메뉴선택 : "))

play_list=[]
alist=[]
for count in range(6):
     a = random.randint(1,45)
     while a in alist:
          a = random.randint(1,45)
     alist.append(a)
if select_num == 1:
     for count in range(6):
          randnum= random.randint(1,45)
          while randnum in play_list:
               randnum = random.randint(1,45)
          play_list.append(randnum)

     print(alist)
     print(play_list)

if select_num == 2:
     for count in range(6):
          picknum = int(input("번호를 골라주세요(1~45)"))
          while picknum in play_list:
               picknum = int(input("중복입니다 다시골라주세요"))
          play_list.append(picknum)

     print(alist)
     print(play_list)

if select_num == 3:
     print("끝")